<?php // ------- yBlog Page Variables -----------------------//
	$TITLE 		= "On this Site"; 	//default=SITE_NAME
	$DESC		= "For Creators and Protectors of Beauty";	//default=SITE_DESC
	$PAGE_TYPE	= "Blog";				//default=article
	$BLOG_DIR	= "";					//
	$MENU_ORDER	= 0;						//default=1,0 = not menued
require_once 'lib/yBlog.php';
/// /-----------------------------------------------------------//
