<?php // ------- yBlog Page Variables -----------------------//
	$TITLE 		= "Not Found"; 	//default=SITE_NAME
	$DESC			= "Perhaps you should try somewhere else?";//default=SITE_DESC
	$AVATAR		= "img/question.png";						//default=SITE_LOGO
	$MENU_ORDER	= 0;					 	//default=1,0 = not menued
//	$AUTHOR		= "Author";			 	//default=SITE_AUTHOR
	$PAGE_TYPE	= "Website";				//Article (default), Blog, Website
//	$STYLES		= "elegant");			//blue(default), none, box, elegant
//	$SCRIPT		= "js";					//default=js
//	$STYLESHEET = "var1";				//default=var1
//	$ANIMATE		= false;					//default=true
//	$ANALYTICS	= false; 				//default=true
//	$CODEVIEWER = true; 					//default=false
//	$ADOBE_ON	= true;					//default=false
include_once 'yBlog.php';
//-----------------------------------------------------------//?>
