<?php // ------- yBlog Page Variables -----------------------//
	$TITLE 	= "yBlog Site Creator"; //default=SITE_NAME
	$DESC		= "Simple, Powerful, File-Based Content Management System"; //default=SITE_DESC
	$PAGE_TYPE	= "Blog";		//case sensitive; Article(default) or Blog
	$BLOG_DIR	= "cms/";			//directory to list, empty string for current. 
	$MENU_ORDER	= 3;				//default=1,0 = not menued
require_once 'lib/yBlog.php';
/// /-----------------------------------------------------------//
//-----------------------------------------------------------//?>
